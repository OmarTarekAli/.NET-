using TaskManagement.Application.DTOs;

namespace TaskManagement.Application.Interfaces
{
    public interface ITaskService
    {
        Task<TaskDto> CreateAsync(CreateTaskDto dto, CancellationToken cancellationToken = default);
        Task<IEnumerable<TaskDto>> GetAllAsync(bool? isCompleted = null, bool sortByDueDate = false, CancellationToken cancellationToken = default);
        Task<TaskDto?> GetByIdAsync(int id, CancellationToken cancellationToken = default);
        Task<bool> UpdateAsync(int id, UpdateTaskDto dto, CancellationToken cancellationToken = default);
        Task<bool> DeleteAsync(int id, CancellationToken cancellationToken = default);
    }
}
