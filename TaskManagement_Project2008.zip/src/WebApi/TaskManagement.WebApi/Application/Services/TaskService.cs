using TaskManagement.Application.DTOs;
using TaskManagement.Application.Interfaces;
using TaskManagement.Core.Entities;
using TaskManagement.Core.Interfaces;

namespace TaskManagement.Application.Services
{
    public class TaskService : ITaskService
    {
        private readonly ITaskRepository _repo;

        public TaskService(ITaskRepository repo)
        {
            _repo = repo;
        }

        public async Task<TaskDto> CreateAsync(CreateTaskDto dto, CancellationToken cancellationToken = default)
        {
            if (string.IsNullOrWhiteSpace(dto.Title))
                throw new ArgumentException("Title is required.");

            if (dto.Title.Length > 100)
                throw new ArgumentException("Title max length is 100.");

            if (dto.Description != null && dto.Description.Length > 500)
                throw new ArgumentException("Description max length is 500.");

            if (dto.DueDate.HasValue && dto.DueDate.Value <= DateTime.UtcNow)
                throw new ArgumentException("DueDate must be in the future.");

            var entity = new TaskItem
            {
                Title = dto.Title,
                Description = dto.Description,
                DueDate = dto.DueDate,
                IsCompleted = false,
                CreatedAt = DateTime.UtcNow
            };

            var added = await _repo.AddAsync(entity, cancellationToken);

            return MapToDto(added);
        }

        public async Task<IEnumerable<TaskDto>> GetAllAsync(bool? isCompleted = null, bool sortByDueDate = false, CancellationToken cancellationToken = default)
        {
            var items = await _repo.GetAllAsync(isCompleted, sortByDueDate, cancellationToken);
            return items.Select(MapToDto);
        }

        public async Task<TaskDto?> GetByIdAsync(int id, CancellationToken cancellationToken = default)
        {
            var item = await _repo.GetByIdAsync(id, cancellationToken);
            if (item == null) return null;
            return MapToDto(item);
        }

        public async Task<bool> UpdateAsync(int id, UpdateTaskDto dto, CancellationToken cancellationToken = default)
        {
            var existing = await _repo.GetByIdAsync(id, cancellationToken);
            if (existing == null) return false;

            if (dto.Title != null)
            {
                if (string.IsNullOrWhiteSpace(dto.Title))
                    throw new ArgumentException("Title cannot be empty.");
                if (dto.Title.Length > 100) throw new ArgumentException("Title max length is 100.");
                existing.Title = dto.Title;
            }

            if (dto.Description != null)
            {
                if (dto.Description.Length > 500) throw new ArgumentException("Description max length is 500.");
                existing.Description = dto.Description;
            }

            if (dto.DueDate.HasValue)
            {
                if (dto.DueDate.Value <= DateTime.UtcNow)
                    throw new ArgumentException("DueDate must be in the future.");
                existing.DueDate = dto.DueDate;
            }

            if (dto.IsCompleted.HasValue)
                existing.IsCompleted = dto.IsCompleted.Value;

            await _repo.UpdateAsync(existing, cancellationToken);

            return true;
        }

        public async Task<bool> DeleteAsync(int id, CancellationToken cancellationToken = default)
        {
            var existing = await _repo.GetByIdAsync(id, cancellationToken);
            if (existing == null) return false;
            await _repo.DeleteAsync(id, cancellationToken);
            return true;
        }

        private static TaskDto MapToDto(TaskItem t) =>
            new TaskDto
            {
                Id = t.Id,
                Title = t.Title,
                Description = t.Description,
                IsCompleted = t.IsCompleted,
                CreatedAt = t.CreatedAt,
                DueDate = t.DueDate
            };
    }
}
