using TaskManagement.Core.Entities;

namespace TaskManagement.Core.Interfaces
{
    public interface ITaskRepository
    {
        Task<TaskItem> AddAsync(TaskItem task, CancellationToken cancellationToken = default);
        Task<TaskItem?> GetByIdAsync(int id, CancellationToken cancellationToken = default);
        Task<IEnumerable<TaskItem>> GetAllAsync(bool? isCompleted = null, bool sortByDueDate = false, CancellationToken cancellationToken = default);
        Task UpdateAsync(TaskItem task, CancellationToken cancellationToken = default);
        Task DeleteAsync(int id, CancellationToken cancellationToken = default);
    }
}
