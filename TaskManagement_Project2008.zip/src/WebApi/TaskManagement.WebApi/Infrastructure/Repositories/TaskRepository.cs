using Microsoft.EntityFrameworkCore;
using TaskManagement.Core.Entities;
using TaskManagement.Core.Interfaces;
using TaskManagement.Infrastructure.Data;

namespace TaskManagement.Infrastructure.Repositories
{
    public class TaskRepository : ITaskRepository
    {
        private readonly AppDbContext _db;

        public TaskRepository(AppDbContext db)
        {
            _db = db;
        }

        public async Task<TaskItem> AddAsync(TaskItem task, CancellationToken cancellationToken = default)
        {
            _db.Tasks.Add(task);
            await _db.SaveChangesAsync(cancellationToken);
            return task;
        }

        public async Task DeleteAsync(int id, CancellationToken cancellationToken = default)
        {
            var t = await _db.Tasks.FindAsync(new object[] { id }, cancellationToken);
            if (t != null)
            {
                _db.Tasks.Remove(t);
                await _db.SaveChangesAsync(cancellationToken);
            }
        }

        public async Task<IEnumerable<TaskItem>> GetAllAsync(bool? isCompleted = null, bool sortByDueDate = false, CancellationToken cancellationToken = default)
        {
            IQueryable<TaskItem> q = _db.Tasks.AsNoTracking();
            if (isCompleted.HasValue)
                q = q.Where(x => x.IsCompleted == isCompleted.Value);

            if (sortByDueDate)
                q = q.OrderBy(x => x.DueDate);

            return await q.ToListAsync(cancellationToken);
        }

        public async Task<TaskItem?> GetByIdAsync(int id, CancellationToken cancellationToken = default)
        {
            return await _db.Tasks.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id, cancellationToken);
        }

        public async Task UpdateAsync(TaskItem task, CancellationToken cancellationToken = default)
        {
            _db.Tasks.Update(task);
            await _db.SaveChangesAsync(cancellationToken);
        }
    }
}
