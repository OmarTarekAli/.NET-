using Microsoft.EntityFrameworkCore;
using TaskManagement.Infrastructure.Data;
using TaskManagement.Infrastructure.Repositories;
using TaskManagement.Core.Entities;
using Xunit;

public class TaskRepositoryTests
{
    private AppDbContext GetInMemoryDb()
    {
        var options = new DbContextOptionsBuilder<AppDbContext>()
            .UseInMemoryDatabase($"testdb_{Guid.NewGuid()}")
            .Options;
        return new AppDbContext(options);
    }

    [Fact]
    public async Task AddAndGetById_Works()
    {
        using var db = GetInMemoryDb();
        var repo = new TaskRepository(db);

        var task = new TaskItem { Title = "t1", Description = "d", DueDate = DateTime.UtcNow.AddDays(1) };

        var added = await repo.AddAsync(task);
        Assert.True(added.Id > 0 || added.Id == 0);

        var fetched = await repo.GetByIdAsync(added.Id);
        Assert.NotNull(fetched);
        Assert.Equal("t1", fetched!.Title);
    }

    [Fact]
    public async Task GetAll_FilterAndSort_Works()
    {
        using var db = GetInMemoryDb();
        var repo = new TaskRepository(db);

        await repo.AddAsync(new TaskItem { Title = "a", DueDate = DateTime.UtcNow.AddDays(3), IsCompleted = false });
        await repo.AddAsync(new TaskItem { Title = "b", DueDate = DateTime.UtcNow.AddDays(1), IsCompleted = true });
        await repo.AddAsync(new TaskItem { Title = "c", DueDate = DateTime.UtcNow.AddDays(2), IsCompleted = false });

        var all = (await repo.GetAllAsync(isCompleted: false, sortByDueDate: true)).ToList();
        Assert.Equal(2, all.Count);
        Assert.True(all[0].DueDate <= all[1].DueDate);
    }

    [Fact]
    public async Task UpdateAndDelete_Works()
    {
        using var db = GetInMemoryDb();
        var repo = new TaskRepository(db);

        var t = await repo.AddAsync(new TaskItem { Title = "to-delete" });
        t.Title = "updated";
        await repo.UpdateAsync(t);

        var fetched = await repo.GetByIdAsync(t.Id);
        Assert.Equal("updated", fetched!.Title);

        await repo.DeleteAsync(t.Id);
        var after = await repo.GetByIdAsync(t.Id);
        Assert.Null(after);
    }
}
